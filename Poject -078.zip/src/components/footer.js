import React from 'react'

const Footer = () => {
  return (
    <footer>
        <p>Created by <a href="#">iZainIqbal</a> with <i class="uil uil-heart-alt"></i></p>
    </footer>
  )
}

export default Footer;
